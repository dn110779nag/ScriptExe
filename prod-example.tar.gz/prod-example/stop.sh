./script-exe-1.0.jar stop
