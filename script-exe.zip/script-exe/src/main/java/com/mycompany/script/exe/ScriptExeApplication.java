package com.mycompany.script.exe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ScriptExeApplication {

	public static void main(String[] args) {
		SpringApplication.run(ScriptExeApplication.class, args);
	}
}
