
#cd /opt/apache-tomcat/pay-bot-backend/
rm ./logs/*
./script-exe-1.0.jar restart

