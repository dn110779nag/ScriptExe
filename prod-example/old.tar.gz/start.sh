
#cd /opt/apache-tomcat/pay-bot-backend/
./script-exe-1.0.jar start
